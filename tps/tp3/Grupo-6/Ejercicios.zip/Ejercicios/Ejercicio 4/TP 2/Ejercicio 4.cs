﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSumar_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double resultado = num1 + num2;
            lblResultado.Text = "Resultado: " + resultado.ToString("#,0.##");
        }

        private void btnRestar_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double resultado = num1 - num2;
            lblResultado.Text = "Resultado: " + resultado.ToString("#,0.##");
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double resultado = num1 * num2;
            lblResultado.Text = "Resultado: " + resultado.ToString("#,0.##");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double resultado = num1 / num2;
            lblResultado.Text = "Resultado: " + resultado.ToString("#,0.##");
        }

        private void btnPotencia_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double potencia1 = Math.Pow(num1, num2);
            double potencia2 = Math.Pow(num2, num1);

            lblResultado.Text = "Numero 1 elevado al numero 2: " + potencia1.ToString("#,0.##") + " | Numero 2 elevado al numero 1: " + potencia2.ToString("#,0.##");
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);

            double raiz1 = Math.Sqrt(num1);
            double raiz2 = Math.Sqrt(num2);

            lblResultado.Text = "Raiz cuadrada del Numero 1: " + raiz1.ToString("#,0.##") + " | Raiz cuadrada del Numero 2: " + raiz2.ToString("#,0.##");
        }
    }
}
