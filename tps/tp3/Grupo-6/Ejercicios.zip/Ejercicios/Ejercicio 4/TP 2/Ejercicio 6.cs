﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            listBoxFibonacci.Items.Clear();

            int n = int.Parse(txtCantidad.Text);

            long a = 0;
            long b = 1;

            if(n >= 1)
            {
                listBoxFibonacci.Items.Add(a);
            }

            if(n >= 2)
            {
                listBoxFibonacci.Items.Add(b);
            }

            for(int i = 3; i <= n; i++)
            {
                long c = a + b;
                listBoxFibonacci.Items.Add(c);

                a = b;
                b = c;
            }
        }
    }
}
