﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP_2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            listBoxPrimos.Items.Clear();

            int minimo = int.Parse(txtMinimo.Text);
            int maximo = int.Parse(txtMaximo.Text);

            for (int i = minimo;  i <= maximo; i++)
            {
                int cantidadDivisores = 0;

                for (int j = 1;  j <= i; j++)
                {
                    if (i %  j == 0)
                    {
                        cantidadDivisores++;
                    }
                }

                if (cantidadDivisores == 2)
                {
                    listBoxPrimos.Items.Add(i);
                }
            }
        }
    }
}
