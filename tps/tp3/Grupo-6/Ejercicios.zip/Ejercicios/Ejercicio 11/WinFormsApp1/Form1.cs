namespace WinFormsApp1
{
    public partial class Form1 : Form
    {   
        private bool turnoX = true;
        private int turnosjugados= 0; 
        public Form1()
        {
            InitializeComponent();
            AsignarEventosBotones();


        }
        private void iniciarjuego()
        {

            Random random = new Random();
            int numeroinicio = random.Next(1, 3);
            if (numeroinicio == 1)
            {

                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button8.Visible = true;
                button9.Visible = true;
                button10.Visible = false;
               
            }
            else
            {
                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button8.Visible = true;
                button9.Visible = true;
                button10.Visible = false;
                
            }



        }

        private void AsignarEventosBotones()
        {
            button1.Click += Boton_Click;
            button2.Click += Boton_Click;
            button3.Click += Boton_Click;
            button4.Click += Boton_Click;
            button5.Click += Boton_Click;
            button6.Click += Boton_Click;
            button7.Click += Boton_Click;
            button8.Click += Boton_Click;
            button9.Click += Boton_Click;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

            iniciarjuego();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Button[] botones = { button1, button2, button3, button4, button5, button6, button7, button8, button9 };

            foreach (Button btn in botones)
            {
                btn.Text = "";
                btn.Enabled = true;
            }

            turnoX = true;
            turnosjugados = 0;
        }

        private void Boton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            // Si el bot�n ya tiene texto, no hace nada
            if (btn.Text != "") return;

            if (turnoX)
            {
                btn.Text = "X";
            }
            else
            {
                btn.Text = "O";
            }

            turnosjugados++;

            if (VerificarGanador())
            {
                string ganador = turnoX ? "X" : "O";
                MessageBox.Show($"�El ganador es {ganador}!", "Fin del juego");
                DeshabilitarBotones();
            }
            else if (turnosjugados == 9)
            {
                MessageBox.Show("�Es un empate!", "Fin del juego");
            }
            else
            {
                // Cambia el turno
                turnoX = !turnoX;
            }
        }
        private bool VerificarGanador()
        {
            // Filas
            if (ComprobarTerna(button1, button2, button3)) return true;
            if (ComprobarTerna(button4, button5, button6)) return true;
            if (ComprobarTerna(button7, button8, button9)) return true;

            // Columnas
            if (ComprobarTerna(button1, button4, button7)) return true;
            if (ComprobarTerna(button2, button5, button8)) return true;
            if (ComprobarTerna(button3, button6, button9)) return true;

            // Diagonales
            if (ComprobarTerna(button1, button5, button9)) return true;
            if (ComprobarTerna(button3, button5, button7)) return true;

            return false;
        }
        private void DeshabilitarBotones()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
        }
        private bool ComprobarTerna(Button b1, Button b2, Button b3)
        {
            return (b1.Text != "" && b1.Text == b2.Text && b2.Text == b3.Text);
        }
    }

}
