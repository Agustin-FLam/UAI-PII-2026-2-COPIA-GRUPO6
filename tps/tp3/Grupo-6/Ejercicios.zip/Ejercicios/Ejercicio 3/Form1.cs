using System.Linq.Expressions;

namespace Ejercicio_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int suma = 0;
                string vueltas = Microsoft.VisualBasic.Interaction.InputBox("Cuantos valores desea Ingresar?");
                int n = int.Parse(vueltas);
                for (int i = 0; i < n; i++)
                {
                    string valor = Microsoft.VisualBasic.Interaction.InputBox("Ingrese un valor");
                    int num = int.Parse(valor);
                    suma += num;
                    textBox1.Text = textBox1.Text + num.ToString() + Environment.NewLine;
                    label1.Text = "La suma es: " + suma.ToString();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:Ingresaste un Valor Incorrecto " + ex.Message);
            }
        }
    }
}
