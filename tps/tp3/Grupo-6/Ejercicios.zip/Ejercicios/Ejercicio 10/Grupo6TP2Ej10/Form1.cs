﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grupo6TP2Ej10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GrillaTemp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        public double Final = 0, Temp = 0;
        public int Entrada = 0, Salida = 0;

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            Entrada = Convert.ToInt32(txtTempInicial.Text);
            Salida = Convert.ToInt32(txtTempFinal.Text);
            Temp = Convert.ToInt32(txtGrados.Text);
            if (Entrada > 4 || Salida > 4 || Entrada < 1 || Salida < 1)
            {
                lblResultados.Text = "Ingrese un numero entre 1 y 4 en ambos campos";
            }
            else if (Entrada == 1 && Salida == 1)
            {
                Final = Temp;
            }
            else if (Entrada == 1 && Salida == 2) 
            {
                Final = Temp * 1.8 + 32;
            }
            else if (Entrada == 1 && Salida == 3)
            {
                Final = Temp + 273.15;
            }
            else if (Entrada == 1 && Salida == 4)
            {
                Final = Temp * 9 / 5 + 491.67;
            }
            else if (Entrada == 2 && Salida == 1)
            {
                Final = (Temp - 32) * 5 / 9; 
            }
            else if (Entrada == 2 && Salida == 2)
            {
                Final = Temp;
            }
            else if (Entrada == 2 && Salida == 3)
            {
                Final = (Temp - 32) * 5 / 9 + 273.15;
            }
            else if (Entrada == 2 && Salida == 4)
            {
                Final = Temp + 459.67;
            }
            else if (Entrada == 3 && Salida == 1)
            {
                Final = Temp - 273.15;
            }
            else if (Entrada == 3 && Salida == 2)
            {
                Final = 1.8 * (Temp - 273) + 32; 
            }
            else if (Entrada == 3 && Salida == 3)
            {
                Final = Temp;
            }
            else if (Entrada == 3 && Salida == 4)
            {
                Final = Temp * 9 / 5;
            }
            else if (Entrada == 4 && Salida == 1)
            {
                Final = (Temp - 491.67) / 1.8;
            }
            else if (Entrada == 4 && Salida == 2)
            {
                Final = Temp - 459.67;
            }
            else if (Entrada == 4 && Salida == 3)
            {
                Final = ((Temp - 491.67) / 1.8) + 273.15;
            }
            else if (Entrada == 4 && Salida == 4)
            {
                Final = Temp;
            }
            GrillaTemp.ColumnCount = 3;
            GrillaTemp.Columns[0].Name = "Unidad Inicial";
            GrillaTemp.Columns[1].Name = "Convertido A";
            GrillaTemp.Columns[2].Name = "Resultado";
            string UnidadEntrada = "a", UnidadSalida = "a";
            if(Entrada == 1) 
            {
                UnidadEntrada = "Celsius";
            }
            if (Entrada == 2)
            {
                UnidadEntrada = "Farenheit";
            }
            if (Entrada == 3)
            {
                UnidadEntrada = "Kelvin";
            }
            if (Entrada == 4)
            {
                UnidadEntrada = "Rankine";
            }
            if (Salida == 1)
            {
                UnidadSalida = "Celsius";
            }
            if (Salida == 2)
            {
                UnidadSalida = "Farenheit";
            }
            if (Salida == 3)
            {
                UnidadSalida = "Kelvin";
            }
            if (Salida == 4)
            {
                UnidadSalida = "Rankine";
            }
            GrillaTemp.Rows.Add(UnidadEntrada, UnidadSalida, Final);
        }
    }
}
