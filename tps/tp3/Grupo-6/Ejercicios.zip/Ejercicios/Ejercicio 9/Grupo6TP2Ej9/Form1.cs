﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grupo6TP2Ej9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        int uno = 0, dos = 0, tres = 0, cuatro = 0, cinco = 0, seis = 0;


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Roll_Click(object sender, EventArgs e)
        {
            Random caras = new Random();
            int Dado = caras.Next(1, 7);
            label1.Text = Dado.ToString();
            switch(Dado)
            {
                case 1:
                    uno+=1;
                    break;
                case 2:
                    dos+=1;
                    break;
                case 3:
                    tres+=1;
                    break; 
                case 4:
                    cuatro+=1;
                    break; 
                case 5:
                    cinco+=1;
                    break; 
                case 6: 
                    seis+=1;
                    break;  
            }
            float Tiradas = uno + dos + tres + cuatro + cinco + seis;
            float porcentaje1 = 0, porcentaje2 = 0, porcentaje3 = 0, porcentaje4 = 0, porcentaje5 = 0, porcentaje6 = 0;

            if (uno > 0)
            {
                 porcentaje1 = (uno / Tiradas) * 100;
            }
            if (dos > 0)
            {
                 porcentaje2 = (dos / Tiradas) * 100;
            }
            if (tres > 0)
            {
                 porcentaje3 = (tres / Tiradas) * 100;
            }
            if (cuatro > 0)
            {
                 porcentaje4 = (cuatro / Tiradas) * 100;
            }
            if (cinco > 0)
            {
                 porcentaje5 = (cinco / Tiradas) * 100;
            }
            if (seis > 0)
            {
                 porcentaje6 = (seis / Tiradas) * 100;
            }

            LblResultados.Text = "1 = " + uno.ToString() + " Porcentaje: " + porcentaje1.ToString() + "%";
            label2.Text = "2 = " + dos.ToString() + " Porcentaje: " + porcentaje2 + "%\n";
            label3.Text = "3 = " + tres.ToString() + " Porcentaje: " + porcentaje3 + "%\n";
            label4.Text = "4 = " + cuatro.ToString() + " Porcentaje: " + porcentaje4 + "%\n";
            label5.Text = "5 = " + cinco.ToString() + " Porcentaje: " + porcentaje5 + "%\n";
            label6.Text = "6 = " + seis.ToString() + " Porcentaje: " + porcentaje6 + "%\n";
        }

        private void LblResultados_Click(object sender, EventArgs e)
        {

        }
    }
}
