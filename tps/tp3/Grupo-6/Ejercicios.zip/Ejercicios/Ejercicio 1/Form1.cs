﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio1tp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada1 = Interaction.InputBox("Ingrese el primer número");
            string entrada2 = Interaction.InputBox("Ingrese el segundo número");

            int num1 = Convert.ToInt32(entrada1);
            int num2 = Convert.ToInt32(entrada2);
            int suma = num1 + num2;

            MessageBox.Show("La suma es: " + suma);
        }
    }
}
