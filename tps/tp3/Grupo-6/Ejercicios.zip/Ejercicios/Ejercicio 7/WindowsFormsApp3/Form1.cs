﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace PlazoFijoApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            dgvResultados.AutoGenerateColumns = false;
            dgvResultados.AllowUserToAddRows = false;

            if (dgvResultados.Columns.Count == 0)
            {
                dgvResultados.Columns.Add(CreateColumn("Monto", "Monto"));
                dgvResultados.Columns.Add(CreateColumn("Tasa", "Tasa (%)"));
                dgvResultados.Columns.Add(CreateColumn("Dias", "Días"));
                dgvResultados.Columns.Add(CreateColumn("Interes", "Interés"));
            }
        }

        private DataGridViewColumn CreateColumn(string name, string header)
        {
            var col = new DataGridViewTextBoxColumn();
            col.Name = name;
            col.HeaderText = header;
            col.ReadOnly = true;
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            return col;
        }

        private void btnCalcularAgregar_Click(object sender, EventArgs e)
        {
            if (!TryParseMonto(txtMonto.Text, out decimal monto))
            {
                MessageBox.Show("Ingrese un monto válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMonto.Focus();
                return;
            }

            if (!TryParseTasa(txtTasa.Text, out decimal tasa))
            {
                MessageBox.Show("Ingrese una tasa válida en porcentaje.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTasa.Focus();
                return;
            }

            if (!int.TryParse(txtDias.Text.Trim(), out int dias) || dias <= 0)
            {
                MessageBox.Show("Ingrese una cantidad de días válida.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDias.Focus();
                return;
            }

            decimal interes = CalcularInteres(monto, tasa, dias);

            string montoStr = monto.ToString("N2", CultureInfo.CurrentCulture);
            string tasaStr = tasa.ToString("N2", CultureInfo.CurrentCulture);
            string diasStr = dias.ToString();
            string interesStr = interes.ToString("N2", CultureInfo.CurrentCulture);

            dgvResultados.Rows.Add(montoStr, tasaStr, diasStr, interesStr);

            lblUltimoResultado.Text = $"Último interés calculado: {interesStr}";
        }

        private decimal CalcularInteres(decimal monto, decimal tasa, int dias)
        {

            return monto * tasa * dias / 36500m;
        }

        private bool TryParseMonto(string s, out decimal value)
        {
            s = s.Trim();
            if (decimal.TryParse(s, System.Globalization.NumberStyles.Number, CultureInfo.CurrentCulture, out value))
            {
                if (value >= 0m) return true;
            }
            value = 0m;
            return false;
        }

        private bool TryParseTasa(string s, out decimal value)
        {
            s = s.Trim();
            if (decimal.TryParse(s, System.Globalization.NumberStyles.Number, CultureInfo.CurrentCulture, out value))
            {
                return true;
            }
            value = 0m;
            return false;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            txtMonto.Clear();
            txtTasa.Clear();
            txtDias.Clear();
            txtMonto.Focus();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvResultados.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una fila para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            foreach (DataGridViewRow row in dgvResultados.SelectedRows)
            {
                if (!row.IsNewRow)
                    dgvResultados.Rows.Remove(row);
            }
        }

        private void dgvResultados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
