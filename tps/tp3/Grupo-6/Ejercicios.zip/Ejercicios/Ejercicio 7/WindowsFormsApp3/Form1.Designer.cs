﻿namespace PlazoFijoApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.Label lblTasa;
        private System.Windows.Forms.Label lblDias;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.TextBox txtTasa;
        private System.Windows.Forms.TextBox txtDias;
        private System.Windows.Forms.Button btnCalcularAgregar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView dgvResultados;
        private System.Windows.Forms.Label lblUltimoResultado;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblMonto = new System.Windows.Forms.Label();
            this.lblTasa = new System.Windows.Forms.Label();
            this.lblDias = new System.Windows.Forms.Label();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.txtTasa = new System.Windows.Forms.TextBox();
            this.txtDias = new System.Windows.Forms.TextBox();
            this.btnCalcularAgregar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.lblUltimoResultado = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMonto
            // 
            this.lblMonto.AutoSize = true;
            this.lblMonto.Font = new System.Drawing.Font("Cascadia Code", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonto.Location = new System.Drawing.Point(52, 16);
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(56, 17);
            this.lblMonto.TabIndex = 0;
            this.lblMonto.Text = "Monto:";
            // 
            // lblTasa
            // 
            this.lblTasa.AutoSize = true;
            this.lblTasa.Font = new System.Drawing.Font("Cascadia Code", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTasa.Location = new System.Drawing.Point(12, 45);
            this.lblTasa.Name = "lblTasa";
            this.lblTasa.Size = new System.Drawing.Size(96, 17);
            this.lblTasa.TabIndex = 1;
            this.lblTasa.Text = "Tasa anual:";
            // 
            // lblDias
            // 
            this.lblDias.AutoSize = true;
            this.lblDias.Font = new System.Drawing.Font("Cascadia Code", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDias.Location = new System.Drawing.Point(60, 75);
            this.lblDias.Name = "lblDias";
            this.lblDias.Size = new System.Drawing.Size(48, 17);
            this.lblDias.TabIndex = 2;
            this.lblDias.Text = "Días:";
            // 
            // txtMonto
            // 
            this.txtMonto.Location = new System.Drawing.Point(100, 12);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(150, 20);
            this.txtMonto.TabIndex = 3;
            // 
            // txtTasa
            // 
            this.txtTasa.Location = new System.Drawing.Point(100, 42);
            this.txtTasa.Name = "txtTasa";
            this.txtTasa.Size = new System.Drawing.Size(150, 20);
            this.txtTasa.TabIndex = 4;
            // 
            // txtDias
            // 
            this.txtDias.Location = new System.Drawing.Point(100, 72);
            this.txtDias.Name = "txtDias";
            this.txtDias.Size = new System.Drawing.Size(150, 20);
            this.txtDias.TabIndex = 5;
            // 
            // btnCalcularAgregar
            // 
            this.btnCalcularAgregar.Location = new System.Drawing.Point(270, 10);
            this.btnCalcularAgregar.Name = "btnCalcularAgregar";
            this.btnCalcularAgregar.Size = new System.Drawing.Size(120, 23);
            this.btnCalcularAgregar.TabIndex = 6;
            this.btnCalcularAgregar.Text = "Calcular y Agregar";
            this.btnCalcularAgregar.UseVisualStyleBackColor = true;
            this.btnCalcularAgregar.Click += new System.EventHandler(this.btnCalcularAgregar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(270, 39);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(120, 23);
            this.btnNuevo.TabIndex = 7;
            this.btnNuevo.Text = "Limpiar";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(270, 68);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(120, 23);
            this.btnEliminar.TabIndex = 8;
            this.btnEliminar.Text = "Eliminar fila";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // dgvResultados
            // 
            this.dgvResultados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(15, 110);
            this.dgvResultados.MultiSelect = false;
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvResultados.Size = new System.Drawing.Size(600, 257);
            this.dgvResultados.TabIndex = 9;
            this.dgvResultados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResultados_CellContentClick);
            // 
            // lblUltimoResultado
            // 
            this.lblUltimoResultado.AutoSize = true;
            this.lblUltimoResultado.Location = new System.Drawing.Point(15, 95);
            this.lblUltimoResultado.Name = "lblUltimoResultado";
            this.lblUltimoResultado.Size = new System.Drawing.Size(0, 13);
            this.lblUltimoResultado.TabIndex = 10;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(634, 411);
            this.Controls.Add(this.lblUltimoResultado);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnNuevo);
            this.Controls.Add(this.btnCalcularAgregar);
            this.Controls.Add(this.txtDias);
            this.Controls.Add(this.txtTasa);
            this.Controls.Add(this.txtMonto);
            this.Controls.Add(this.lblDias);
            this.Controls.Add(this.lblTasa);
            this.Controls.Add(this.lblMonto);
            this.Name = "Form1";
            this.Text = "Calculadora de Intereses - Plazo Fijo";
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
